<?php

return [
    'file_title' => [
        'author_name'   => 'Curator',
    ],
    'default'   => [
        'cols'   => ['status', 'admin_remark', 'timestamps', 'updated_by', 'deleted_at'],
    ],
];
