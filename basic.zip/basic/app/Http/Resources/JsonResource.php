<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource AS BasicResource;

class JsonResource extends BasicResource
{
    public $additional = [
        'res'   => 1,
        'mes'   => 'OK',
    ];
}
