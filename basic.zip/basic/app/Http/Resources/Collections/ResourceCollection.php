<?php

namespace App\Http\Resources\Collections;

use Illuminate\Http\Resources\Json\ResourceCollection as BasicCollection;

class ResourceCollection extends BasicCollection
{

    public function toArray($request)
    {
        return [
            'data' => $this->collection,
            'res' => 1,
            'mes' => 'OK!',
        ];
    }
}
