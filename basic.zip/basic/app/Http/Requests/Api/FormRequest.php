<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\FormRequest AS BasicRequest;

class FormRequest extends BasicRequest
{

}

