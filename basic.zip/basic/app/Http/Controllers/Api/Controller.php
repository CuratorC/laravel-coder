<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller AS BasicController;

class Controller extends BasicController
{
    //
}
