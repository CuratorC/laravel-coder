<?php

namespace App\Observers;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Auth;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class UserObserver
{

}
